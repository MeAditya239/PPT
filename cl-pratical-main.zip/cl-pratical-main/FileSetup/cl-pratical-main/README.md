# cl-pratical
 how to execute pratical no 11 in vscode
 💡 How to Run in VS Code

1. **Install Pyro4** (if not already):
   
   pip install Pyro4
   

2. **Run the Server** in a new terminal:
   
   python hotel_booking_server.py
   

4. **Run the Client** in another terminal:
  
   python hotel_booking_client.py
  

Now you can interact with the hotel booking system via terminal inputs (BOOK, CANCEL, EXIT). Make sure all files are in the same folder.



OR 



The server failed with this error:

 Error : Pyro4.errors.NamingError: Failed to locate the nameserver

This means:
✅ Pyro4 is installed and working
❌ But the Pyro name server (which helps locate the actual service) is not running

----------------------------------------------------------------------------------------

✅ Fix: Start the Pyro Name Server
You tried running Pyro4 as a command — that’s not correct.

Instead, in PowerShell or CMD, run:

python -m Pyro4.naming   or   Pyro4-ns 



This starts the name server on port 9090. You should see something like:

   Pyro name server.
   NS running on localhost:9090 (127.0.0.1)

-----------------------------------------------------------------------------------------

🔁 Keep this window open — it must run continuously in the background.


----------------------------------------------------------------------------------------


✅ Now retry steps:
Terminal 1:(In new treminal)
Run:

python -m Pyro4.naming

------------------------------------------------------------------------------------------

Terminal 2:
Run the server:(In new terminal)

python hotel_booking_server.py

--------------------------------------------------------------------------------------------

Terminal 3:
 Run the client: (In new terminal) 

python hotel_booking_client.py

--------------------------------------------------------------------------------------------

🔍 Verifying It's Working
After running the name server, your hotel_booking_server.py should now show:

Hotel Booking Server is ready.

=================================================================================================
