# part 2 of code 
# hotel_booking_server.py 

import Pyro4 
 
@Pyro4.expose 
class HotelBookingServer: 
    def __init__(self): 
        self.rooms = {} 
 
    def book_room(self, guest, room): 
        if room in self.rooms: 
            return f"Room {room} is already booked." 
        else: 
            self.rooms[room] = guest 
            return f"Room {room} booked for {guest}." 
 
    def cancel_booking(self, guest): 
        for room, booked_guest in list(self.rooms.items()): 
            if booked_guest == guest: 
                del self.rooms[room] 
                return f"Booking for {guest} cancelled." 
        return f"No booking found for {guest}." 
 
if __name__ == "__main__": 
    daemon = Pyro4.Daemon() 
    ns = Pyro4.locateNS() 
    server = HotelBookingServer() 
    uri = daemon.register(server) 
    ns.register("hotel.booking.server", uri) 
    print("Hotel Booking Server is ready.") 
    daemon.requestLoop()
